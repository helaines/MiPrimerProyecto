
package ecofriendly;

import java.util.Date;

public class Empleados {

  String Nombre;
  String Apellido;
  int Cedula;
  int CantHijos;
  int HorasTrabajadas;
  private int Antiguedad;
  Date FechaAlta;
  Date FechaBaja;
  boolean EmpleadoPorHora;
  boolean EmpleadoTemporal;
  boolean EmpleadoPermanente;
  
    public static void main(String[] args) {
    
    }
    Object[][] getNombre;
 public double calcularSueldo() {
        double sueldo = 0;
        if (EmpleadoPorHora) {
            sueldo = 100 * HorasTrabajadas;
        } else if (EmpleadoTemporal) {
            sueldo = 18000 + (CantHijos * 1000);
        } else if (EmpleadoPermanente) {
            sueldo = 20000 + (CantHijos * 1000) + (Antiguedad * 1000);
        }
        return sueldo;
    }

    public Empleados() {
    }

    public Empleados(String Nombre, String Apellido, int Cedula, int CantHijos, int HorasTrabajadas, int Antiguedad, Date FechaAlta, Date FechaBaja, boolean EmpleadoPorHora, boolean EmpleadoTemporal, boolean EmpleadoPermanente) {
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Cedula = Cedula;
        this.CantHijos = CantHijos;
        this.HorasTrabajadas = HorasTrabajadas;
        this.Antiguedad = Antiguedad;
        this.FechaAlta = FechaAlta;
        this.FechaBaja = FechaBaja;
        this.EmpleadoPorHora = EmpleadoPorHora;
        this.EmpleadoTemporal = EmpleadoTemporal;
        this.EmpleadoPermanente = EmpleadoPermanente;
    }


    public String getNombre() {
        return Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public int getCedula() {
        return Cedula;
    }

    public int getCantHijos() {
        return CantHijos;
    }

    public int getHorasTrabajadas() {
        return HorasTrabajadas;
    }

    public int getAntiguedad() {
        return Antiguedad;
    }

    public Date getFechaAlta() {
        return FechaAlta;
    }

    public Date getFechaBaja() {
        return FechaBaja;
    }

    public boolean getEmpleadoPorHora() {
        return EmpleadoPorHora;
    }

    public boolean getEmpleadoTemporal() {
        return EmpleadoTemporal;
    }

    public boolean getEmpleadoPermanente() {
        return EmpleadoPermanente;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public void setCedula(int Cedula) {
        this.Cedula = Cedula;
    }

    public void setCantHijos(int CantHijos) {
        this.CantHijos = CantHijos;
    }

    public void setHorasTrabajadas(int HorasTrabajadas) {
        this.HorasTrabajadas = HorasTrabajadas;
    }

    public void setAntiguedad(int Antiguedad) {
        this.Antiguedad = Antiguedad;
    }

    public void setFechaAlta(Date FechaAlta) {
        this.FechaAlta = FechaAlta;
    }

    public void setFechaBaja(Date FechaBaja) {
        this.FechaBaja = FechaBaja;
    }

    public void setEmpleadoPorHora(boolean EmpleadoPorHora) {
        this.EmpleadoPorHora = EmpleadoPorHora;
    }

    public void setEmpleadoTemporal(boolean EmpleadoTemporal) {
        this.EmpleadoTemporal = EmpleadoTemporal;
    }

    public void setEmpleadoPermanente(boolean EmpleadoPermanente) {
        this.EmpleadoPermanente = EmpleadoPermanente;
    }




}