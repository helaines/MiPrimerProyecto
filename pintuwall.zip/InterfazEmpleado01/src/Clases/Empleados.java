
package Clases;

import java.util.Date;


public class Empleados {

    private String nombre;
    private String apellido;
    private String cedula;
    private int cantidadHijos;
    private TipoEmpleado tipoEmpleado;
    private int horasTrabajadas; // Solo para empleados por hora
    private Date fechaAlta; // Solo para empleados temporales
    private Date fechaBaja; // Solo para empleados temporales
    private int antiguedad; // Solo para empleados de planta permanente

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getCedula() {
        return cedula;
    }

    public int getCantidadHijos() {
        return cantidadHijos;
    }

    public TipoEmpleado getTipoEmpleado() {
        return tipoEmpleado;
    }

    public int getHorasTrabajadas() {
        return horasTrabajadas;
    }

    public Date getFechaAlta() {
        return fechaAlta;
    }

    public Date getFechaBaja() {
        return fechaBaja;
    }

    public int getAntiguedad() {
        return antiguedad;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public void setCantidadHijos(int cantidadHijos) {
        this.cantidadHijos = cantidadHijos;
    }

    public void setTipoEmpleado(TipoEmpleado tipoEmpleado) {
        this.tipoEmpleado = tipoEmpleado;
    }

    public void setHorasTrabajadas(int horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }

    public void setFechaAlta(Date fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public void setFechaBaja(Date fechaBaja) {
        this.fechaBaja = fechaBaja;
    }

    public void setAntiguedad(int antiguedad) {
        this.antiguedad = antiguedad;
    }

   
    // Método para calcular el sueldo
    public double calcularSueldo() {
        double sueldo = 0;
        switch (tipoEmpleado) {
            case TEMPORAL -> sueldo = 18000 + (cantidadHijos * 1000);
            case PLANTA_PERMANENTE -> sueldo = 20000 + (cantidadHijos * 1000) + (antiguedad * 1000);
            case POR_HORA -> sueldo = 100 * horasTrabajadas;
        }
        return sueldo;
    }

    @Override
    public String toString() {
        return "Empleados{" + "nombre=" + nombre + ", apellido=" + apellido + ", cedula=" + cedula + ", cantidadHijos=" + cantidadHijos + ", tipoEmpleado=" + tipoEmpleado + ", horasTrabajadas=" + horasTrabajadas + ", fechaAlta=" + fechaAlta + ", fechaBaja=" + fechaBaja + ", antiguedad=" + antiguedad + '}';
    }

    // Enum para el tipo de empleado
    public enum TipoEmpleado {
        TEMPORAL, PLANTA_PERMANENTE, POR_HORA;
    }
}