
package Clases;

public class ListaEmpleados {

    private Empleados[] empleados = new Empleados[100]; // Tamaño inicial de la lista
    private int cantidadEmpleados = 0; // Contador de empleados

    // Método para agregar un empleado
    public void agregarEmpleado(Empleados empleado) {
        if (cantidadEmpleados < empleados.length) {
            empleados[cantidadEmpleados++] = empleado;
        } else {
            // Implementar la lógica para ampliar la lista si se necesita
        }
    }

    // Método para eliminar un empleado por su cédula
    public void eliminarEmpleado(String cedula) {
        for (int i = 0; i < cantidadEmpleados; i++) {
            if (empleados[i].getCedula().equals(cedula)) {
                for (int j = i; j < cantidadEmpleados - 1; j++) {
                    empleados[j] = empleados[j + 1];
                }
                cantidadEmpleados--;
                break;
            }
        }
    }

    public void setEmpleados(Empleados[] empleados) {
        this.empleados = empleados;
    }

    public void setCantidadEmpleados(int cantidadEmpleados) {
        this.cantidadEmpleados = cantidadEmpleados;
    }

    public Empleados[] getEmpleados() {
        return empleados;
    }

    public int getCantidadEmpleados() {
        return cantidadEmpleados;
    }

}