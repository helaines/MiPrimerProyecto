import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/calcular.jsp")
public class CalcularServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Obtener valores del formulario
        String figuraSeleccionada = request.getParameter("figura");
        double lado1 = Double.parseDouble(request.getParameter("lado1"));
        double lado2 = 0;
        double lado3 = 0;

        if (request.getParameter("lado2") != null) {
        }
    }
        }